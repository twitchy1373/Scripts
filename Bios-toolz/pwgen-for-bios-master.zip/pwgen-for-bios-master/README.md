   Pwgen For BIOS 
============================

    About
---------------------------
This code are based on python programs from [Dogbert&#39;s Blog](http://dogber1.blogspot.com/2009/05/table-of-reverse-engineered-bios.html).

It can calculate password for bios by hash.
For more information [read this](http://dogber1.blogspot.com/2009/05/table-of-reverse-engineered-bios.html).